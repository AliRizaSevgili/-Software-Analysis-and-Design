/**
 * WEB222 – Assignment 06
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Dragomira Veleva
 *      Student ID: 184787216
 *      Date:       05.12.2023
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.

const { artists, songs } = window;

let artistMenu = document.querySelector("#menu");
let artistInfo = document.querySelector("#selected-artist");

const defaultArtist = artists.find((artist) => artist.name === "Jennifer Lopez");

function displaySongs(artistId) {
  const artistSongs = songs.filter((song) => song.artistId === artistId);
  const songsContainer = document.getElementById("songs");
  songsContainer.innerHTML = "";

  artistSongs.forEach((song) => {
    const card = createSongCard(song);
    songsContainer.appendChild(card);
  });
}

function updateSelectedArtist(artist) {
  artistInfo.innerHTML = `${artist.name} &nbsp;( `;
  artist.urls.forEach((url, urlIndex) => {
    artistInfo.innerHTML += `<a href="${url.url}" target="_blank">${url.name}</a>`;
    if (urlIndex < artist.urls.length - 1) {
      artistInfo.innerHTML += ", ";
    }
  });
  artistInfo.innerHTML += ` )`;
}

function selectArtist(artist) {
  updateSelectedArtist(artist);
  displaySongs(artist.artistId);
}

selectArtist(defaultArtist);

artists.forEach((artist, index) => {
  let artistElement = document.createElement("p");
  artistElement.innerHTML = artist.name;
  artistElement.style.cursor = "pointer";
  artistElement.style.fontWeight = "bold";
  artistElement.style.color = "#00a4fc";
  if (index < artists.length - 1) {
    artistElement.style.marginRight = "40px";
  }
  artistElement.addEventListener("click", function () {
    selectArtist(artist);
  });

  artistElement.addEventListener("mouseover", function () {
    artistElement.style.textDecoration = "underline";
  });

  artistElement.addEventListener("mouseout", function () {
    artistElement.style.textDecoration = "none";
  });

  artistMenu.appendChild(artistElement);
});

artistMenu.style.display = "flex";

function createSongCard(song) {
  const card = document.createElement("div");
  card.classList.add("card");

  const songImg = document.createElement("img");
  songImg.src = song.imageUrl;
  songImg.alt = song.title;
  songImg.classList.add("card-image");
  card.appendChild(songImg);

  const songTitle = document.createElement("h3");
  songTitle.textContent = song.title;
  card.appendChild(songTitle);

  const cardInfo = document.createElement("div");
  cardInfo.classList.add("card-info");

  const yearRecorded = document.createElement("p");
  yearRecorded.textContent = `${song.year}`;
  cardInfo.appendChild(yearRecorded);

  const duration = document.createElement("p");
  const minutes = Math.floor(song.duration / 60);
  const seconds = song.duration % 60;
  duration.textContent = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  cardInfo.appendChild(duration);

  card.appendChild(cardInfo);

  songImg.addEventListener("click", function () {
    window.open(song.url, "_blank");
  });

  return card;
}


document.getElementById('add-song-url').addEventListener('click', function() {
    const container = document.getElementById('song-urls-container');
    const newInput = document.createElement('input');
    newInput.type = 'url';
    newInput.name = 'songUrls';
    newInput.required = true;
    container.appendChild(newInput);
});

console.log({ artists, songs }, "App Data");
