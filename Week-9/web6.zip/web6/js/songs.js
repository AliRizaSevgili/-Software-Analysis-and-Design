

window.songs = [
 
  {
    songId: "SID-999",
    artistId: "AID-1234",
    title:"Jennifer Lopez - Booty ft. Iggy Azalea",
    year: "2014",
    duration: "256",
    url: "https://www.youtube.com/watch?v=nxtIRArhVD4",
    imageUrl: "https://th.bing.com/th/id/R.ee70a9a4c520c11340495a643086780f?rik=N6YskESVWTBftg&riu=http%3a%2f%2fwww.diariodigitalcolombiano.com%2fwp-content%2fuploads%2f2015%2f03%2fFeel-The-Light-jennifer-lopez-video.png&ehk=PkC8VjcJa9FAf%2fxNqR9KNl0IxRNueqAgmEN54jxlIts%3d&risl=&pid=ImgRaw&r=0"
  },
  {
    songId: "SID-999",
    artistId: "AID-1234",
    title: "Jennifer Lopez - Papi (Official Video)",
    year: "2011",
    duration: "325",
    url: "https://www.youtube.com/watch?v=6XbIuSLaCnk",
    explicit: false,
    imageUrl: "https://images2.alphacoders.com/156/thumb-1920-156800.jpg"
  },
  {
    songId: "SID-997",
    artistId: "AID-1234",
    title: "Jennifer Lopez - Booty ft. Iggy Azalea",
    year: "2014",
    duration: "256",
    url: "https://www.youtube.com/watch?v=nxtIRArhVD4",
    explicit: false,
    imageUrl: "https://yt3.ggpht.com/a-/AN66SAxsfw_A8onpeL9R2nK8TaxIMM-PMaTVzZ1NCA=s900-mo-c-c0xffffffff-rj-k-no"
  },
  {
    songId: "SID-996",
    artistId: "AID-1234",
    title: "Jennifer Lopez - On The Floor ft. Pitbull",
    year: "2011",
    duration: "256",
    url: "https://www.youtube.com/watch?v=t4H_Zoh7G5A",
    explicit: true,
    imageUrl: "https://i.pinimg.com/originals/49/35/8c/49358c666b694c5b0da36b1489ee50e1.jpg"
  },
  {
    songId: "SID-995",
    artistId: "AID-1234",
    title: "Jennifer Lopez - Dance Again (Official Video) ft. Pitbull",
    year: "2002",
    duration: "266",
    url: "https://www.youtube.com/watch?v=bjgFH01k0gU",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/OIP.wpVKN4a35z1IlMZSmnoOqAAAAA?rs=1&pid=ImgDetMain"
  },

  {
    songId: "SID-884",
    artistId: "AID-1235",
    title: "Hips Don't Lie",
    year: "2023",
    duration: "627",
    url: "https://www.youtube.com/watch?v=zAxmn4ihqNg",
    explicit: false,
    imageUrl: "https://4.bp.blogspot.com/_IB9p9X14tW4/SKR9SR8ggfI/AAAAAAAAAEc/rLzed7a3RDc/s800/shakira2.jpg"
  },
  {
    songId: "SID-885",
    artistId: "AID-1235",
    title: "Waka Waka",
    year: "2010",
    duration: "210",
    url: "https://www.youtube.com/watch?v=pRpeEdMmmQ0",
    explicit: false,
    imageUrl: "https://thewallpapers.org/zoom/4284/Shakira12.jpg"
  },
  {
    songId: "SID-886",
    artistId: "AID-1235",
    title: "Whenever, Wherever",
    year: "2009",
    duration: "196",
    url: "https://www.youtube.com/watch?v=weRHyjj34ZE",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/R.30fa3b5862135e5a074800a911bdbf91?rik=J6%2fQhElyhaAxBQ&riu=http%3a%2f%2f4.bp.blogspot.com%2f-xwwhcd-PYDw%2fTa8lkIlytMI%2fAAAAAAAAAXE%2fXf9PkPWi4u4%2fs1600%2fshakira-in-red-dress-in-photo-shots-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-shakira-in-red-dress-.jpg&ehk=zUURwBAIgOVtkmyhAtqo8a4jZHAfyg%2fjOmkskYTh8ts%3d&risl=&pid=ImgRaw&r=0"
  },
  {
    songId: "SID-887",
    artistId: "AID-1235",
    title: "Chantaje",
    year: "2017",
    duration: "199",
    url: "https://www.youtube.com/watch?v=6Mgqbai3fKo",
    explicit: false,
    imageUrl: "https://rnow.today/__export/1593610071571/sites/mui/img/2020/07/01/shakira.jpg_554688468.jpg"
  },
  {
    songId: "SID-888",
    artistId: "AID-1235",
    title: "Maluma - Clandestino",
    year: "2018",
    duration: "235",
    url: "https://www.youtube.com/watch?v=1DhA69K3fZ4",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/R.40c25d952a239976aa41a6aa2899ab76?rik=xMzy6jHBQUL2gg&riu=http%3a%2f%2f2.bp.blogspot.com%2f-BGQP73C9aK4%2fUfQWd2Z_W4I%2fAAAAAAAAJiw%2fY-QSQ1LqcPo%2fs1600%2fSHAKIRA1.jpg&ehk=7oz6lIxfPh17EdOooBT3HI9n8QA34UaY9TwQt7tQkqI%3d&risl=&pid=ImgRaw&r=0"
  },
  {
    songId: "SID-991",
    artistId: "AID-12356",
    title: "Give It Up To Me",
    year: "2022",
    duration: "212",
    url: "https://www.youtube.com/watch?v=Mx_OexsUI2M",
    explicit: false,
    imageUrl: "https://i.pinimg.com/originals/bc/6f/2f/bc6f2fef8e76c3ef12787524234ae57e.jpg"
  },
  {
    songId: "SID-992",
    artistId: "AID-12356",
    title: "What's My Name? ft. Drake",
    year: "2010",
    duration: "264",
    url: "https://www.youtube.com/watch?v=U0CGsw6h60k",
    explicit: false,
    imageUrl: "https://i.pinimg.com/originals/6d/38/26/6d3826d63670676f1943ee8337068cac.jpg"
  },
  {
    songId: "SID-993",
    artistId: "AID-12356",
    title: "If It's Lovin' That You Want ",
    year: "2011",
    duration: "216",
    url: "https://www.youtube.com/watch?v=hD5MRBzY1uM",
    explicit: false,
    imageUrl: "https://i.pinimg.com/originals/a3/bc/8b/a3bc8b3aa3a78d1a80237d2c7d1d11e3.jpg"
  },
  {
    songId: "SID-994",
    artistId: "AID-12356",
    title: "Hate That I Love You ft. Ne-Yo",
    year: "2010",
    duration: "297",
    url: "https://www.youtube.com/watch?v=KMOOr7GEkj8",
    explicit: false,
    imageUrl: "https://static.seattletimes.com/wp-content/uploads/2020/10/urn-publicid-ap-org-023596089010710d064fa60b376adc36Music_-_Rihanna_43633-375x468.jpg"
  },
  {
    songId: "SID-995",
    artistId: "AID-12356",
    title: "Russian Roulette",
    year: "2010",
    duration: "263",
    url: "https://www.youtube.com/watch?v=ZQ2nCGawrSY",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/OIP.NdiC0XOjsb_Ev7XO_lKS5QHaLH?w=768&h=1153&rs=1&pid=ImgDetMain"
  },
  {
    songId: "SID-100",
    artistId: "AID-1234567",
    title: "Hello",
    year: "2015",
    duration: "366",
    url: "https://www.youtube.com/watch?v=YQHsXMglC9A",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/R.1f516eae5bf3051e37447261c5afc8cd?rik=oO%2biZnuZlAJgbg&riu=http%3a%2f%2f1.bp.blogspot.com%2f-3mnYjf13dQ4%2fT4QFJKyeSMI%2fAAAAAAAAAVQ%2fl_qROQArpuw%2fw1200-h630-p-k-no-nu%2fAdele-Someone-Like-You.jpg&ehk=EEl6NKAw6xXSNufRQjrYhSnPirPyEghs4%2fAXdyg3ivE%3d&risl=&pid=ImgRaw&r=0"
  },
  {
    songId: "SID-101",
    artistId: "AID-1234567",
    title: "Someone Like You",
    year: "2011",
    duration: "284",
    url: "https://www.youtube.com/watch?v=hLQl3WQQoQ0",
    explicit: false,
    imageUrl: "https://gazettereview.com/wp-content/uploads/2015/07/adele-now.png"
  },
  {
    songId: "SID-102",
    artistId: "AID-1234567",
    title: "Easy On Me ",
    year: "2022",
    duration: "225",
    url: "https://www.youtube.com/watch?v=X-yIEMduRXk",
    explicit: false,
    imageUrl: "https://gl-images.condecdn.net/image/ReD9BP4YAG9/crop/592/square/top"
  },
  {
    songId: "SID-103",
    artistId: "AID-1234567",
    title: "Send My Love",
    year: "2016",
    duration: "225",
    url: "https://www.youtube.com/watch?v=fk4BbF7B29w",
    explicit: false,
    imageUrl: "https://th.bing.com/th/id/R.0a74f6efe814131bae968f7f781cc9ed?rik=TCg50OTrgh7Iaw&riu=http%3a%2f%2fimages5.fanpop.com%2fimage%2fphotos%2f24900000%2fAdele-MTV-VMA-2011-adele-24952608-1669-2048.jpg&ehk=9ChX6fvuyk0Qj6X%2f%2f0fYDbcGUAb5GpadmWEVWu9AEr8%3d&risl=&pid=ImgRaw&r=0"
  },
  {
    songId: "SID-104",
    artistId: "AID-1234567",
    title: "When We Were Young ",
    year: "2023",
    duration: "282",
    url: "https://www.youtube.com/watch?v=a1IuJLebHgM",
    explicit: false,
    imageUrl: "https://a-static.besthdwallpaper.com/songwriter-musician-adele-pose-wallpaper-1280x1024-116604_32.jpg"
  },
  
];
