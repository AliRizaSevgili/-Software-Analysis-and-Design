window.artists = [
  {
    artistId: "AID-1234",
    name: "Jennifer Lopez",
    urls: [
      { url: "https://www.youtube.com/results?search_query=Jennifer+Lopez+music", name: "Youtube" }
    ]
  },
  {
    artistId: "AID-1235",
    name: "Shakira",
    urls: [
      { url: "https://www.youtube.com/results?search_query=shakira+songs", name: "Youtube" },
    ]
  },
  {
    artistId: "AID-12356",
    name: "Rihanna",
    urls: [
      { url: "https://www.youtube.com/results?search_query=rihana+songs", name: "Youtube" },
  
    ]
  },
  {
    artistId: "AID-1234567",
    name: "Adele",
    urls: [
      { url: "https://www.youtube.com/results?search_query=adele+songs", name: "Youtube" },
    ]
  }
];
